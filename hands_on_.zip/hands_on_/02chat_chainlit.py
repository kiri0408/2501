##### シンプルチャット #####

# 1.ライブラリのインポート
import chainlit as cl
from langchain_openai import AzureChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# 2.LLMモデルの定義
model = AzureChatOpenAI( deployment_name="gpt-4o-3"
                        ,openai_api_version="2024-10-21"
                        ,max_tokens= 100     # LLMからの回答の最大トークン数  (LLMからの回答が長くなってしまうことがあるので試行では上限を設定する)
                        )  

# 3.LLM処理の流れ（chain）の定義 
prompt = ChatPromptTemplate.from_messages(["{user_message}"])
chain = prompt | model | StrOutputParser()

# 4.処理開始時にchainをセット 
@cl.on_chat_start
def start():
    cl.user_session.set("chain", chain)

# 5.ユーザ入力時にchainを使ってLLMから回答を得てブラウザに表示 
@cl.on_message
async def main(message: cl.Message):
    chain = cl.user_session.get("chain")
    response = await cl.make_async(chain.invoke)({"user_message": message.content})
    await cl.Message(content=response).send()


